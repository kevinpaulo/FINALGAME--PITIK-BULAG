
bootGame = {

		create:function(){
				game.physics.startSystem(Phaser.Physics.ARCADE);
			
				game.state.start("preloadGame");
				keyboard = game.input.keyboard.createCursorKeys();
		}
}

preloadGame = {
	preload: function(){

		
    game.stage.backgroundColor = "#dce1df";
    game.load.spritesheet('tuo2','assets/image/6.png',522,480);
game.load.image("front", "assets/image/front.png");
    game.load.image("up", "assets/image/1.png");
    game.load.image("down", "assets/image/2.png");
    game.load.image("right", "assets/image/3.png");
    game.load.image("left", "assets/image/4.png");
    game.load.image("back","assets/image/back.png");
   game.load.image("XXX","assets/image/XXX.png");
    game.load.image('play', 'assets/image/PlayBtn.png');
    game.load.image('PrevBtn', 'assets/image/PrevBtn.png');
    game.load.image('about', 'assets/image/About.png');
    game.load.image('AboutBtn', 'assets/image/AboutBtn.png');

    game.load.audio('clickAudio', 'assets/audio/appear.wav');
		
	},

	create:function(){
		game.state.start("menuGame");
	}
}

menuGame = {
	create:function(){

		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    	game.scale.forcePortrait = true;
    	game.scale.forceLandscape = false;
    	game.scale.pageAlignVertically = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.setScreenSize = true;
		game.scale.refresh();

		//game.stage.backgroundColor = "#DCDCDC";
		
		// home = game.add.image(0,0,'home');
		// home.scale.set(1.4);
        frnt = game.add.button(w/2,300,"front",this.fronts);
        frnt.anchor.set(0.5);
        frnt.scale.x = 1.4;
        frnt.scale.y = 1.4;
	

    	pbtn = game.add.button(w/2,425,"play",this.lundag);
        pbtn.anchor.set(0.5);
        pbtn.scale.x = 1.4;
        pbtn.scale.y = 1.4;



        abtn = game.add.button(w/2,530,"AboutBtn",this.aboutp);
        abtn.anchor.set(0.5);
        abtn.scale.x = 1.4;
        abtn.scale.y = 1.4;


		// menuText = game.add.text(w/2,h/2, "Menu", {"fill":"red"});
  //       menuText.anchor.setTo(0.5,0.5);
		// menuText.scale.x = 1.3;
		// menuText.scale.y = 1.3;

		// playText = game.add.text(w/2,350, "Play", {"fill":"blue"});
  //       playText.anchor.setTo(0.5,0.5);
		// playText.scale.x = 1.3;
		// playText.scale.y = 1.3;

		console.log("current state: menu");

	},
	update:function(){
			if(keyboard.up.isDown){
				game.state.start("playGame");
			}
	},
	lundag:function (){
        game.state.start("playGame");
   },
   aboutp:function (){
        about = game.add.image(0,0,'about');
        about.scale.x = 1.4;
        about.scale.y = 1.3;

        prevbtn = game.add.button(60,40,"PrevBtn",prevf);
        prevbtn.anchor.set(0.5);
        prevbtn.scale.x = 0.3;
        prevbtn.scale.y = 0.3;

        function prevf() {
            prevbtn.visible =! prevbtn.visible;
            prevbtn.destroy();


             window.location.href=window.location.href;
            }
   },
}

playGame = {

create:function () {
    game.physics.startSystem(Phaser.Physics.ARCADE);    
    player = game.add.sprite(0,0,'tuo2');

    player.animations.add('up',[1,2,3,4],1000,true);
    player.animations.add('down',[3,2,1,4],1000,true);
    player.animations.add('right',[2,1,3,4],1000,true);
    player.animations.add('left',[2,3,1,4],1000,true);
    player.animations.add('back',[0],1000,true);
    clickaudio = game.add.audio('clickAudio');

    prevbtn = game.add.button(350,40,"PrevBtn",prevf);
        prevbtn.anchor.set(0.5);
        prevbtn.scale.x = 0.3;
        prevbtn.scale.y = 0.3;

        function prevf() {
            game.state.start("menuGame");
            }
    
   // player.animations.add('walaLang',[4,0,2,3,1],1000,true);
    keyboard = game.input.keyboard.createCursorKeys();
    game.physics.arcade.enable(player);
   
    // backgroundMusic = game.add.audio("backgroundMusic");
    // backgroundMusic.play();
    
   // score = game.add.text(5,0,'Score ko :',{font: '16px bonnie',fill:"orange"});
    //score = game.add.text(5,15,'AI :',{font: '16px bonnie',fill:"orange"});
   //topScore = game.add.text(10,40,"High Score: "+getScore(),{font: '12px Arial',fill:"orange"});
    //stateText = game.add.text(game.world.centerX,game.world.centerY,' ', { font: '30px Arial', fill: 'orange' });
   
    button = game.add.button(16,515,"up",this.pushUp);
    button = game.add.button(116,515,"down",this.pushDown);
    button = game.add.button(216,515,"right",this.pushRight);
    button = game.add.button(316,515,"left",this.pushLeft);
button=game.add.button(120,420,"back",this.back);

    picture = game.add.sprite(game.world.centerX, game.world.centerY, 'XXX');
    picture.anchor.setTo(0.5, 0.6);
    game.time.events.add(Phaser.Timer.SECOND * 1, this.fadePicture, this);


},
update:function () {
    if(keyboard.left.isDown){
        player.animations.play('left');
    }
    else if(keyboard.right.isDown){
        player.animations.play('right');
    }
    else if(keyboard.up.isDown){
        player.animations.play('up');
    }
    else if(keyboard.down.isDown){
        player.animations.play('down');
    }
    else{
        player.animations.stop();
    }

    if(keyboard.up.isDown && player.body.touching.down){
        console.log("x");         
    }

    if(player.body.touching.down){
        console.log("x");
    }
},
pushUp:function (){
    clickaudio.play();
    player.animations.play('up');
},
pushDown:function (){
    clickaudio.play();
    player.animations.play('down');
},
pushRight:function (){
    clickaudio.play();
    player.animations.play('right');
},
pushLeft:function (){
    clickaudio.play();
    player.animations.play('left');
},
back:function (){
    clickaudio.play();
    player.animations.play('back');
},
fadePicture:function () {

    game.add.tween(picture).to( { alpha: 0 }, 2000, Phaser.Easing.Linear.None, true);
},

};		

winGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}

loseGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}
